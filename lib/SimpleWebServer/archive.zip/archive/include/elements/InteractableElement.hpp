#pragma once

#include "BaseElement.h"

template <typename T>
class InteractableElement : public BaseElement
{
protected:
    typedef void (*ElementCallback)(T);
    ElementCallback callback;

public:
    InteractableElement(int size, String identifier, String label, ElementCallback callback);
    void setCallback(ElementCallback callback);
    void executeCallback(const T &value) const;

    virtual String toString() = 0;
    virtual void accept(ElementVisitor &visitor) override;
};

// Specialization for InteractableElement with T = void
template <>
class InteractableElement<void> : public BaseElement
{
protected:
    typedef void (*ElementCallback)();
    ElementCallback callback;

public:
    InteractableElement(int size, String identifier, String label, ElementCallback callback);
    void setCallback(ElementCallback callback);
    void executeCallback() const;

    virtual String toString() = 0;
    virtual void accept(ElementVisitor &visitor) override;
};