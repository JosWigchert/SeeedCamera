#pragma once

#include "elements/BaseElement.h"
#include "elements/InteractableElement.hpp"

#include <ArduinoJson.h>

class ElementVisitor
{
public:
    ElementVisitor(ArduinoJson::V6213PB2::detail::MemberProxy<ArduinoJson::V6213PB2::JsonDocument &, const char *> jsonValue);

    void visit(InteractableElement<void> &element);
    template <typename T>
    void visit(InteractableElement<T> &element);
    void visit(BaseElement &element);

private: 
    ArduinoJson::V6213PB2::detail::MemberProxy<ArduinoJson::V6213PB2::JsonDocument &, const char *> jsonValue;
};

