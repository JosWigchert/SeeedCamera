#include "ElementVisitor.h"

#include "elements/InteractableElement.tpp"


ElementVisitor::ElementVisitor(ArduinoJson::V6213PB2::detail::MemberProxy<ArduinoJson::V6213PB2::JsonDocument &, const char *> jsonValue)
    : jsonValue(jsonValue)
{
}

void ElementVisitor::visit(InteractableElement<void> &element)
{
    element.executeCallback();
    Serial.print("Callback for void");
}


template <typename T>
void ElementVisitor::visit(InteractableElement<T> &element)
{
    element.executeCallback(jsonValue.as<T>());
    Serial.print("Callback for T");
}


void ElementVisitor::visit(BaseElement &element)
{
    return;
}